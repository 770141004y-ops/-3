# يولّد src/envelope.json (شدة الصوت لكل فريم 30fps) — يحتاج ffmpeg و numpy
import subprocess, json, numpy as np
raw = subprocess.run(['ffmpeg','-v','error','-i','public/voice.mp3','-ac','1','-ar','8000','-f','s16le','-'],
                     capture_output=True, check=True).stdout
x = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768
sr, fps = 8000, 30
n = int(len(x) / sr * fps) + 40
r = np.array([float(np.sqrt(np.mean(x[int(i/fps*sr):int((i+1)/fps*sr)]**2))) if len(x[int(i/fps*sr):int((i+1)/fps*sr)]) else 0.0 for i in range(n)])
r = np.clip(r / np.percentile(r, 97), 0, 1)
r = np.convolve(r, [.25, .5, .25], mode='same')
json.dump([round(float(v), 3) for v in r], open('src/envelope.json', 'w'))
print('ok', len(r))
