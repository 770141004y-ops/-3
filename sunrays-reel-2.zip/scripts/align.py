#!/usr/bin/env python3
"""
align.py — يستخرج توقيت كل كلمة من ملف الصوت نفسه ويطابقها مع النص المكتوب.

الطرق (اختر واحدة):
  1) Whisper (تلقائي، يعمل داخل GitHub Actions):
       python scripts/align.py --audio public/voice.mp3 --script script.txt --out src/timing.json
  2) توقيت ElevenLabs الجاهز (الأدق إن توفّر — JSON فيه characters و character_start_times_seconds ...):
       python scripts/align.py --elevenlabs alignment.json --script script.txt --out src/timing.json
  3) نتيجة تعرّف جاهزة (للاختبار): --recognized rec.json  = [{"w":"كلمة","t0":0.1,"t1":0.4}, ...]

المخرج timing.json:
  {"duration": 45.2, "match_ratio": 0.93, "words": [{"i":0,"text":"مرفوض","t0":0.05,"t1":0.52,"matched":true}, ...]}
النص الظاهر في الفيديو هو نص script.txt دائمًا (وليس ما كتبه Whisper).
يخرج بخطأ (exit 2) إذا كانت نسبة المطابقة أقل من --min-ratio أو التوقيتات غير منطقية، فلا يُنتج فيديو غير مضبوط بصمت.
"""
import argparse, difflib, json, re, subprocess, sys

TASHKEEL = re.compile(r'[\u064B-\u065F\u0670\u0640]')
PUNCT = re.compile(r'[^\w\u0600-\u06FF]+', re.UNICODE)
DIGITS = str.maketrans('٠١٢٣٤٥٦٧٨٩', '0123456789')


def norm(w: str) -> str:
    w = TASHKEEL.sub('', w).translate(DIGITS)
    w = re.sub('[أإآٱ]', 'ا', w).replace('ى', 'ي').replace('ة', 'ه')
    w = ''.join(c for c in w if c.isalnum())
    # أداة التعريف/الواو الملتصقة تتغير كثيرًا في التعرّف، نبقيها لكن نخفف الفروق
    return w.lower()


def script_words(path):
    txt = open(path, encoding='utf-8').read()
    return [w for w in txt.split() if norm(w)]


def whisper_words(audio, model_size, lang):
    from faster_whisper import WhisperModel
    model = WhisperModel(model_size, device='cpu', compute_type='int8')
    segs, _ = model.transcribe(audio, language=lang, word_timestamps=True, vad_filter=False)
    out = []
    for s in segs:
        for w in (s.words or []):
            t = w.word.strip()
            if norm(t):
                out.append({'w': t, 't0': float(w.start), 't1': float(w.end)})
    return out


def eleven_words(path):
    d = json.load(open(path, encoding='utf-8'))
    d = d.get('alignment', d.get('normalized_alignment', d))
    ch, st, en = d['characters'], d['character_start_times_seconds'], d['character_end_times_seconds']
    words, cur, t0 = [], '', None
    for c, a, b in zip(ch, st, en):
        if c.isspace():
            if cur:
                words.append({'w': cur, 't0': t0, 't1': prev_end})
            cur, t0 = '', None
            continue
        if t0 is None:
            t0 = a
        cur += c
        prev_end = b
    if cur:
        words.append({'w': cur, 't0': t0, 't1': prev_end})
    return [w for w in words if norm(w['w'])]


def match(script, rec):
    a = [norm(w) for w in script]
    b = [norm(w['w']) for w in rec]
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    res = [None] * len(script)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal' or (tag == 'replace' and (i2 - i1) == (j2 - j1)):
            for k in range(i2 - i1):
                res[i1 + k] = (rec[j1 + k]['t0'], rec[j1 + k]['t1'])
    return res


def fill(script, res, rec_start, rec_end):
    n = len(script)
    out = [None] * n
    for i, r in enumerate(res):
        if r:
            out[i] = {'t0': r[0], 't1': r[1], 'matched': True}
    i = 0
    while i < n:
        if out[i]:
            i += 1
            continue
        j = i
        while j < n and not out[j]:
            j += 1
        left = out[i - 1]['t1'] if i > 0 else rec_start
        right = out[j]['t0'] if j < n else rec_end
        wts = [len(norm(script[k])) + 1 for k in range(i, j)]
        tot = sum(wts)
        acc = 0
        for k in range(i, j):
            a = left + (right - left) * acc / tot
            acc += wts[k - i]
            b = left + (right - left) * acc / tot
            out[k] = {'t0': a, 't1': b, 'matched': False}
        i = j
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--audio')
    ap.add_argument('--elevenlabs')
    ap.add_argument('--recognized')
    ap.add_argument('--script', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--model', default='small')
    ap.add_argument('--lang', default='ar')
    ap.add_argument('--min-ratio', type=float, default=0.6)
    a = ap.parse_args()

    script = script_words(a.script)
    if a.elevenlabs:
        rec = eleven_words(a.elevenlabs)
    elif a.recognized:
        rec = json.load(open(a.recognized, encoding='utf-8'))
    elif a.audio:
        rec = whisper_words(a.audio, a.model, a.lang)
    else:
        sys.exit('أعطني --audio أو --elevenlabs أو --recognized')
    if not rec:
        print('ERROR: لم يتم التعرف على أي كلمة في الصوت', file=sys.stderr)
        sys.exit(2)

    res = match(script, rec)
    ratio = sum(1 for r in res if r) / len(script)
    words = fill(script, res, rec[0]['t0'], rec[-1]['t1'])

    # فحوصات منطقية
    prev = -1
    for i, w in enumerate(words):
        if w['t1'] < w['t0'] - 1e-6 or w['t0'] < prev - 0.05:
            print(f'ERROR: توقيت غير منطقي عند الكلمة {i} ({script[i]})', file=sys.stderr)
            sys.exit(2)
        prev = w['t0']
    dur = None
    if a.audio:
        try:
            dur = float(subprocess.check_output(
                ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', a.audio]).decode().strip())
        except Exception:
            pass
    if dur and words[-1]['t1'] > dur + 0.5:
        print('ERROR: توقيت آخر كلمة أكبر من مدة الصوت', file=sys.stderr)
        sys.exit(2)

    data = {
        'duration': dur,
        'match_ratio': round(ratio, 3),
        'words': [{'i': i, 'text': script[i], 't0': round(w['t0'], 3), 't1': round(w['t1'], 3), 'matched': w['matched']}
                  for i, w in enumerate(words)],
    }
    json.dump(data, open(a.out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    unmatched = [script[i] for i, w in enumerate(words) if not w['matched']]
    print(f'matched {ratio:.0%} ({len(script) - len(unmatched)}/{len(script)} words)')
    if unmatched:
        print('unmatched (توقيتها مُستكمل بالتناسب):', ' '.join(unmatched))
    if ratio < a.min_ratio:
        print(f'ERROR: نسبة المطابقة {ratio:.0%} أقل من {a.min_ratio:.0%} — النص لا يطابق الصوت. راجع script.txt.', file=sys.stderr)
        sys.exit(2)


if __name__ == '__main__':
    main()
