# يولّد public/music.mp3 : موسيقى خلفية هادئة + مؤثرات (ضربات/ووش/رنين) متزامنة مع لحظات الإعلان
# يحتاج numpy و ffmpeg.  تشغيل:  python3 scripts/make_music.py
import numpy as np, subprocess, wave, json, argparse
# الاستخدام: python3 scripts/make_music.py --cues cues.json
# cues.json = {"duration":46.2,"pulse_from":11.0,"chord_changes":[11.0,23.5,35.6],
#              "hits":[[0.0,0.55],[11.0,0.5]],"whooshes":[2.2,5.0],"chimes":[[11.0,880.0]]}
# الأفضل: python3 scripts/make_music.py --timing src/timing.json --spec music_spec.json
# music_spec.json = {"pulse_from":{"word":"برنامج"},"chord_changes":[{"word":"برنامج"}],"hits":[{"word":"مرفوض","gain":0.55}],"whooshes":[{"word":"طيب","offset":-0.45}],"chimes":[{"word":"برنامج","freq":880}]}
# (قوائم كل نوع مرتبة كما تُنطق في النص). الأوقات تأتي من الصوت، لا تُكتب بيدك.
ap = argparse.ArgumentParser(); ap.add_argument('--cues'); ap.add_argument('--out', default='public/music.mp3')
ap.add_argument('--timing'); ap.add_argument('--spec')  # الأفضل: توقيت من timing.json + كلمات مرجعية من music_spec.json
_a = ap.parse_args()

def _build_from_words(timing_path, spec_path):
    import re
    T = json.load(open(timing_path, encoding='utf-8')); S = json.load(open(spec_path, encoding='utf-8'))
    W = T['words']
    def nz(w):
        w = re.sub('[\u064B-\u065F\u0670\u0640]', '', w); w = re.sub('[أإآٱ]', 'ا', w).replace('ى', 'ي').replace('ة', 'ه')
        return ''.join(c for c in w if c.isalnum())
    pos = {'i': 0}
    def at(word):
        # يبحث عن الكلمة بالترتيب (بعد آخر كلمة وجدها) — يفشل بوضوح إذا لم توجد
        for k in range(pos['i'], len(W)):
            if nz(W[k]['text']) == nz(word):
                pos['i'] = k
                return W[k]['t0']
        raise SystemExit(f'cue word not found in timing.json: {word}')
    dur = (T.get('duration') or W[-1]['t1']) + S.get('tail', 0.8)
    # كل نوع يُحسب بشكل مستقل بترتيب كلماته في النص (يجب أن تكون قائمة كل نوع مرتبة كما تُنطق)
    def seq(key, f):
        pos['i'] = 0
        return [f(x, at(x['word'])) for x in S.get(key, [])]
    out = {
        'duration': dur,
        'hits': seq('hits', lambda x, t: [t + x.get('offset', 0), x.get('gain', 0.4)]),
        'whooshes': seq('whooshes', lambda x, t: t + x.get('offset', 0)),
        'chimes': seq('chimes', lambda x, t: [t + x.get('offset', 0), x.get('freq', 880.0)]),
        'chord_changes': seq('chord_changes', lambda x, t: t),
    }
    pos['i'] = 0
    out['pulse_from'] = at(S['pulse_from']['word']) if 'pulse_from' in S else out['chord_changes'][0] if out['chord_changes'] else 0.0
    return out

if _a.timing and _a.spec:
    CUES = _build_from_words(_a.timing, _a.spec)
elif _a.cues:
    CUES = json.load(open(_a.cues))
else:
    CUES = {
    'duration': 46.2, 'pulse_from': 11.03, 'chord_changes': [11.03, 23.54, 35.64],
    'hits': [[0.0, 0.55], [11.03, 0.5], [35.64, 0.45], [43.04, 0.55], [17.0, 0.22], [23.54, 0.25]],
    'whooshes': [2.24, 4.99, 13.99, 20.26, 26.18, 30.51, 33.5, 38.41],
    'chimes': [[11.03, 880.0], [12.0, 1318.5], [35.64, 880.0], [43.04, 1174.7], [43.25, 1568.0]]}
SR = 44100
DUR = CUES['duration']
n = int(SR * DUR)
t = np.arange(n) / SR
rng = np.random.default_rng(7)
mix = np.zeros(n, dtype=np.float64)

def add(sig, at, gain=1.0):
    i = int(at * SR)
    if i >= n: return
    j = min(n, i + len(sig))
    mix[i:j] += sig[: j - i] * gain

def env_exp(length, tau):
    x = np.arange(int(length * SR)) / SR
    return np.exp(-x / tau)

# ---------- بساط هارموني (Pad) ----------
_c = [0.0] + CUES['chord_changes'] + [DUR]
_f = [[110.0, 164.81, 220.0, 261.63], [87.31, 130.81, 174.61, 261.63], [65.41, 130.81, 196.0, 329.63], [98.0, 146.83, 196.0, 293.66]]
chords = [(_c[i], _c[i + 1], _f[i % 4]) for i in range(len(_c) - 1)]
pad = np.zeros(n)
for a, b, fr in chords:
    i0, i1 = int(a * SR), min(n, int(b * SR))
    tt = t[i0:i1] - a
    seg = np.zeros(i1 - i0)
    for k, f in enumerate(fr):
        for d in (-0.6, 0.6):
            seg += np.sin(2 * np.pi * (f + d) * tt + k) * (0.5 if k < 2 else 0.35)
    fade = np.minimum(1, tt / 1.2) * np.minimum(1, (b - a - tt) / 1.2)
    pad[i0:i1] += seg * fade * (0.8 + 0.2 * np.sin(2 * np.pi * 0.15 * tt))
mix += pad * 0.022

# ---------- نبض (Kick ناعم) من 11.03 ----------
def kick():
    L = int(0.28 * SR); x = np.arange(L) / SR
    f = 120 * np.exp(-x * 18) + 42
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-x / 0.09)
def hat():
    L = int(0.05 * SR)
    return rng.standard_normal(L) * np.exp(-np.arange(L) / SR / 0.012)
k = kick(); h = hat()
beat = 0.6
tt = CUES['pulse_from']
while tt < DUR - 1.4:
    add(k, tt, 0.20)
    if tt > CUES['pulse_from'] + 12: add(h, tt + beat / 2, 0.035)
    tt += beat

# ---------- ضربات كبيرة (Impact) ----------
def boom(len_s=1.6):
    L = int(len_s * SR); x = np.arange(L) / SR
    f = 150 * np.exp(-x * 4) + 32
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-x / 0.55)
    nz = rng.standard_normal(L) * np.exp(-x / 0.12) * 0.25
    return s + nz
for at, g in CUES['hits']:
    add(boom(), at, g)

# ---------- ووش (Whoosh) قبل الانتقالات ----------
def whoosh(len_s=0.6):
    L = int(len_s * SR); x = np.arange(L) / SR
    nz = rng.standard_normal(L)
    out = np.zeros(L); y = 0.0
    for i in range(L):
        a = 0.02 + 0.45 * (i / L) ** 2
        y += a * (nz[i] - y)
        out[i] = y
    e = np.sin(np.pi * (x / len_s)) ** 2
    return out * e
for at in CUES['whooshes']:
    w = whoosh(0.6)
    add(w, at - 0.45, 0.30)

# ---------- رنين (Chime) على اللحظات الإيجابية ----------
def chime(f0):
    L = int(1.6 * SR); x = np.arange(L) / SR
    s = sum(np.sin(2 * np.pi * f0 * m * x) * a for m, a in [(1, 1), (2, .5), (3, .25), (4.2, .12)])
    return s * np.exp(-x / 0.5)
for at, f in CUES['chimes']:
    add(chime(f), at, 0.05)
# تكّات عدّاد الـ100
for i in range(12):
    L = int(0.03 * SR); tick = np.sin(2 * np.pi * 1800 * np.arange(L) / SR) * np.exp(-np.arange(L) / SR / 0.008)
    add(tick, 17.0 + i * 0.16, 0.06)

# ---------- تطبيع ونهاية ----------
fade_out = np.clip((DUR - t) / 0.8, 0, 1)
mix *= fade_out
peak = np.max(np.abs(mix))
mix = mix / peak * 0.55
pcm = (np.clip(mix, -1, 1) * 32767).astype(np.int16)
with wave.open('/tmp/music.wav', 'wb') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', '/tmp/music.wav', '-b:a', '160k', _a.out], check=True)
print('ok')
