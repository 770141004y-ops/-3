import React from 'react';
import {Composition} from 'remotion';
import {Ad} from './Ad';
import {FPS} from './brand';
import {TOTAL_FRAMES} from './cues';

export const Root: React.FC = () => {
  return (
    <>
      {/* عمودي 9:16 — تيك توك / ريلز / شورتس / ستوري */}
      <Composition
        id="Ad-Vertical"
        component={Ad}
        durationInFrames={TOTAL_FRAMES}
        fps={FPS}
        width={1080}
        height={1920}
      />
      {/* أفقي 16:9 — يوتيوب / تويتر / لينكدإن */}
      <Composition
        id="Ad-Landscape"
        component={Ad}
        durationInFrames={TOTAL_FRAMES}
        fps={FPS}
        width={1920}
        height={1080}
      />
    </>
  );
};
