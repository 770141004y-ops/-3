import React from 'react';
import {useCurrentFrame} from 'remotion';
import {BRAND} from './brand';
import {T} from './timeline';
import {Badge, Cuboid, Extrude, LogoCard, Slab, Stage, ctr} from './ui3d';
import {Glass, Icon, clamp01, fontFamily, lerp, seeded, sp, useScale, useT} from './ui';

const txt = (size: number, color = '#fff', weight = 900): React.CSSProperties => ({
  fontFamily,
  fontWeight: weight,
  fontSize: size,
  color,
  direction: 'rtl',
  whiteSpace: 'nowrap',
  lineHeight: 1.25,
});

const GOLD_FACE = 'linear-gradient(160deg,#fff7d6,#ffd25a 55%,#e0a010)';
const DARK_FACE = 'linear-gradient(160deg,#2a2620,#0d0c0a)';
const RED_FACE = 'linear-gradient(160deg,#ff6a5c,#8a1a12)';

/* ================================================================== *
 *  أيام الأسبوع: بلاطات ثلاثية الأبعاد (تُستخدم في A و E)
 * ================================================================== */
const DayTile: React.FC<{n: number; at: number; dark?: number}> = ({n, at, dark = 0}) => {
  const frame = useCurrentFrame();
  const {u} = useScale();
  const k = clamp01(sp(frame, at, {damping: 11, stiffness: 170}));
  const isDark = dark > 0.5;
  return (
    <div style={{transform: `scale(${0.3 + 0.7 * k}) rotateX(${(1 - k) * 70}deg)`}}>
      <Slab
        w={118 * u}
        h={158 * u}
        r={24 * u}
        depth={16 * u}
        face={isDark ? DARK_FACE : GOLD_FACE}
        side={isDark ? '#241d08' : '#8a6410'}
        glow={isDark ? 'rgba(0,0,0,0)' : 'rgba(255,210,90,0.45)'}
      >
        <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
          <div style={txt(80 * u, isDark ? '#6b5a2a' : '#0b0b0d')}>{['١', '٢', '٣', '٤', '٥', '٦', '٧'][n - 1]}</div>
        </div>
      </Slab>
    </div>
  );
};

const DayRow: React.FC<{start: number; dark?: (i: number) => number}> = ({start, dark}) => {
  const {u} = useScale();
  return (
    <div style={{display: 'flex', gap: 14 * u, direction: 'ltr'}}>
      {[1, 2, 3, 4, 5, 6, 7].map((n) => (
        <DayTile key={n} n={n} at={start + (n - 1) * 0.12} dark={dark ? dark(n) : 0} />
      ))}
    </div>
  );
};

/* ================================================================== *
 *  A) سؤال افتتاحي: سبعة أيام
 * ================================================================== */
export const SceneA: React.FC = () => {
  const frame = useCurrentFrame();
  const {u} = useScale();
  const big = clamp01(sp(frame, T.aSeven, {damping: 9, stiffness: 180}));
  return (
    <div style={{...ctr, flexDirection: 'column', gap: 70 * u}}>
      <div style={{transform: `scale(${0.4 + 0.6 * big})`}}>
        <Extrude text="٧" size={330 * u} color={BRAND.gold} edge="#7a4d00" glow={BRAND.gold} depth={20} />
      </div>
      <DayRow start={T.aWhat} />
    </div>
  );
};

/* ================================================================== *
 *  B) اليوم الأول: المدينة تنطفئ نافذة نافذة
 * ================================================================== */
const BLOCKS = [
  {w: 150, h: 330, x: -330, z: 0},
  {w: 150, h: 470, x: -170, z: 40},
  {w: 150, h: 260, x: -10, z: 0},
  {w: 150, h: 420, x: 150, z: 40},
  {w: 150, h: 300, x: 310, z: 0},
];

export const SceneB: React.FC = () => {
  const frame = useCurrentFrame();
  const t = useT();
  const {u} = useScale();
  const on = clamp01(sp(frame, T.bDay1, {damping: 14, stiffness: 120}));
  // نسبة الإضاءة تتراجع من 1 إلى 0 بين "ستنقطع" و"المنازل"
  const lit = 1 - clamp01((t - T.bOff) / (T.bHomes - T.bOff + 0.5));
  return (
    <div style={{...ctr}}>
      <div style={{position: 'absolute', top: 60 * u, left: 0, right: 0, textAlign: 'center', ...txt(84 * u, BRAND.gold), opacity: on}}>اليوم ١</div>
      <Stage rx={-14} ry={-24}>
        <div style={{position: 'absolute', transform: `translateY(${230 * u}px) scale(${0.6 + 0.4 * on})`}}>
          {BLOCKS.map((b, bi) => (
            <div key={bi} style={{position: 'absolute', left: b.x * u, top: -b.h * u / 2, transform: `translateZ(${b.z * u}px)`}}>
              <Cuboid w={b.w * u} h={b.h * u} d={b.w * u} front="linear-gradient(160deg,#1f2230,#0a0b10)" side="#07080c" top="#2a2e3c">
                <div style={{position: 'absolute', inset: 16 * u, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 * u}}>
                  {Array.from({length: 18}).map((_, wi) => {
                    const threshold = seeded(bi * 31 + wi * 7);
                    const isLit = threshold < lit;
                    return (
                      <div
                        key={wi}
                        style={{
                          borderRadius: 4 * u,
                          background: isLit ? 'linear-gradient(160deg,#fff3c4,#ffb020)' : '#0d0e14',
                          boxShadow: isLit ? `0 0 ${12 * u}px rgba(255,190,40,0.7)` : 'none',
                        }}
                      />
                    );
                  })}
                </div>
              </Cuboid>
            </div>
          ))}
        </div>
      </Stage>
    </div>
  );
};

/* ================================================================== *
 *  C) اليوم الثاني: المياه والاتصالات واللوجستيات
 * ================================================================== */
const NetTile: React.FC<{icon: 'drop' | 'signal' | 'truck'; label: string; at: number}> = ({icon, label, at}) => {
  const frame = useCurrentFrame();
  const t = useT();
  const {u} = useScale();
  const k = clamp01(sp(frame, at, {damping: 12, stiffness: 160}));
  const pulse = 1 + 0.12 * Math.sin((t - at) * 9) * clamp01((t - at) * 2);
  return (
    <div style={{transform: `translateY(${(1 - k) * 160 * u}px) scale(${0.7 + 0.3 * k})`, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 26 * u}}>
      <Glass style={{width: 260 * u, height: 260 * u, borderRadius: 50 * u, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative'}}>
        <Icon name={icon} size={130 * u} color={BRAND.gold} sw={1.6} />
        <div
          style={{
            position: 'absolute',
            top: -14 * u,
            right: -14 * u,
            transform: `scale(${k * pulse})`,
          }}
        >
          <Badge size={70 * u} color={BRAND.red}>
            <Icon name="warn" size={38 * u} color="#fff" sw={2.4} />
          </Badge>
        </div>
      </Glass>
      <div style={txt(56 * u, '#fff')}>{label}</div>
    </div>
  );
};

export const SceneC: React.FC = () => {
  const frame = useCurrentFrame();
  const {u} = useScale();
  const on = clamp01(sp(frame, T.cDay2));
  return (
    <div style={{...ctr, flexDirection: 'column', gap: 70 * u}}>
      <div style={{...txt(84 * u, BRAND.gold), opacity: on}}>اليوم ٢</div>
      <div style={{display: 'flex', gap: 40 * u, direction: 'ltr', alignItems: 'flex-start'}}>
        <NetTile icon="drop" label="المياه" at={T.cWater} />
        <NetTile icon="signal" label="الاتصالات" at={T.cSignal} />
        <NetTile icon="truck" label="اللوجستيات" at={T.cSignal + 1.1} />
      </div>
    </div>
  );
};

/* ================================================================== *
 *  D) اليوم الثالث: الثلاجة ترتفع حرارتها والطعام يتلف
 * ================================================================== */
export const SceneD: React.FC = () => {
  const frame = useCurrentFrame();
  const t = useT();
  const {u} = useScale();
  const on = clamp01(sp(frame, T.dDay3));
  const p = clamp01((t - T.dFridge) / (T.dSpoil - T.dFridge + 0.4));
  const temp = Math.round(lerp(p, 0, 1, 4, 22));
  const spoil = clamp01((t - T.dSpoil) / 0.8 + p * 0.5);
  return (
    <div style={{...ctr, flexDirection: 'column', gap: 60 * u}}>
      <div style={{...txt(84 * u, BRAND.gold), opacity: on}}>اليوم ٣</div>
      <div style={{display: 'flex', alignItems: 'center', gap: 60 * u, direction: 'ltr'}}>
        <div style={{transform: `scale(${0.6 + 0.4 * on})`}}>
          <Cuboid w={300 * u} h={480 * u} d={240 * u} front="linear-gradient(160deg,#e9eef3,#aab4c0)" side="#7d8794" top="#f6f9fb">
            <div style={{position: 'absolute', left: 24 * u, right: 24 * u, top: 40 * u, height: 4 * u, background: '#6d7782'}} />
            <div style={{position: 'absolute', left: 24 * u, right: 24 * u, bottom: 150 * u, height: 4 * u, background: '#6d7782'}} />
            <div style={{position: 'absolute', left: 0, right: 0, bottom: 40 * u, display: 'flex', justifyContent: 'center'}}>
              <div style={{...txt(80 * u, p > 0.7 ? BRAND.red : '#0b0b0d', 900), direction: 'ltr'}}>{temp}°C</div>
            </div>
          </Cuboid>
        </div>
        <div style={{display: 'flex', flexDirection: 'column', gap: 30 * u}}>
          {[0, 1, 2].map((i) => {
            const sp2 = clamp01(spoil * 1.2 - i * 0.2);
            return (
              <div key={i} style={{transform: `rotateY(${(1 - clamp01(sp(frame, T.dDay3 + 0.2 + i * 0.2))) * -90}deg)`}}>
                <Cuboid
                  w={150 * u}
                  h={150 * u}
                  d={150 * u}
                  front={sp2 > 0.5 ? 'linear-gradient(160deg,#6b5a2a,#2a2210)' : 'linear-gradient(160deg,#7dffb3,#2bd67b)'}
                  side="#15301f"
                  top="#a6ffd0"
                />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

/* ================================================================== *
 *  E) مرور الأيام، ثم مفتاح الكهرباء يُطفأ
 * ================================================================== */
export const SceneE: React.FC = () => {
  const frame = useCurrentFrame();
  const t = useT();
  const {u} = useScale();
  const p = clamp01((t - T.eTime) / (T.eDetail - T.eTime));
  const off = clamp01(sp(frame, T.eDetail, {damping: 10, stiffness: 200})); // 0 = مُشغّل، 1 = مُطفأ
  return (
    <div style={{...ctr, flexDirection: 'column', gap: 80 * u}}>
      <DayRow start={T.eTime - 1} dark={(n) => clamp01(p * 7 - (n - 1)) > 0.5 ? 1 : 0} />
      <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 24 * u}}>
        <Glass style={{width: 170 * u, height: 300 * u, borderRadius: 40 * u, display: 'flex', alignItems: 'flex-start', justifyContent: 'center', padding: `${28 * u}px 0`, boxSizing: 'border-box'}}>
          <div
            style={{
              width: 90 * u,
              height: 130 * u,
              borderRadius: 22 * u,
              background: off < 0.5 ? 'linear-gradient(180deg,#ffd25a,#c27a08)' : 'linear-gradient(180deg,#2a2a31,#121216)',
              position: 'relative',
              top: lerp(off, 0, 1, 0, 150) * u,
              boxShadow: off < 0.5 ? '0 0 30px rgba(255,190,40,0.6)' : 'none',
            }}
          />
        </Glass>
        <div style={txt(56 * u, '#fff')}>أبسط التفاصيل</div>
      </div>
    </div>
  );
};

/* ================================================================== *
 *  F) السؤال: الشمس والألواح والبطارية
 * ================================================================== */
export const SceneF: React.FC = () => {
  const frame = useCurrentFrame();
  const t = useT();
  const {u} = useScale();
  const on = clamp01(sp(frame, T.fSolar));
  const qk = clamp01(sp(frame, T.fQ, {damping: 9, stiffness: 180}));
  const flow = (i: number) => {
    const ph = ((t - T.fSolar) * 0.7 + i / 6) % 1;
    const x = lerp(ph, 0, 1, -300, 300) * u;
    const y = Math.sin(ph * Math.PI * 2 + i) * 30 * u;
    return {x, y, a: clamp01(on * 3) * clamp01(1 - Math.abs(ph - 0.5) * 2 + 0.3)};
  };
  return (
    <div style={{...ctr, flexDirection: 'column', gap: 60 * u}}>
      <div style={{transform: `scale(${0.4 + 0.6 * qk})`}}>
        <Extrude text="؟" size={230 * u} color={BRAND.gold} edge="#7a4d00" glow={BRAND.gold} depth={16} />
      </div>
      <div style={{position: 'relative', width: 820 * u, height: 420 * u, display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
        <div style={{transform: `scale(${0.5 + 0.5 * on}) rotateY(-18deg) rotateX(12deg)`}}>
          <Slab w={320 * u} h={230 * u} r={24 * u} depth={22 * u} face="linear-gradient(135deg,#2c3446,#0a0d16)" side="#3a2c08" glow="rgba(255,190,40,0.4)">
            <div style={{position: 'absolute', inset: 22 * u, display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gridTemplateRows: 'repeat(3,1fr)', gap: 8 * u}}>
              {Array.from({length: 12}).map((_, i) => (
                <div key={i} style={{borderRadius: 4 * u, border: `${2 * u}px solid rgba(255,210,90,0.45)`, boxSizing: 'border-box', background: '#141a2a'}} />
              ))}
            </div>
          </Slab>
        </div>
        <div style={{transform: `scale(${0.5 + 0.5 * on})`}}>
          <Cuboid w={210 * u} h={330 * u} d={160 * u} front="linear-gradient(160deg,#25282f,#0d0e12)" side="#07080a" top="#33363f">
            <div style={{position: 'absolute', left: 30 * u, top: 40 * u, width: 60 * u, height: 40 * u, borderRadius: 6 * u, border: `${3 * u}px solid ${BRAND.gold}`, boxSizing: 'border-box'}} />
          </Cuboid>
        </div>
        {[0, 1, 2, 3, 4, 5].map((i) => {
          const f = flow(i);
          return (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: '50%',
                top: '50%',
                width: 26 * u,
                height: 26 * u,
                marginLeft: -13 * u + f.x,
                marginTop: -13 * u + f.y,
                borderRadius: '50%',
                background: BRAND.gold,
                boxShadow: `0 0 ${20 * u}px ${BRAND.gold}`,
                opacity: f.a,
              }}
            />
          );
        })}
      </div>
    </div>
  );
};

/* ================================================================== *
 *  G) الحل: البطارية تمتلئ والمنزل يبقى مضاءً
 * ================================================================== */
export const SceneG: React.FC = () => {
  const frame = useCurrentFrame();
  const t = useT();
  const {u} = useScale();
  const fill = clamp01((t - T.gBattery) / (T.gFit - T.gBattery));
  const bulb = clamp01(sp(frame, T.gContinue, {damping: 9, stiffness: 200}));
  return (
    <div style={{...ctr, flexDirection: 'row', gap: 90 * u}}>
      <div style={{transform: 'rotateY(-12deg)'}}>
        <Cuboid w={250 * u} h={430 * u} d={150 * u} front="linear-gradient(160deg,#1a1c22,#0b0c10)" side="#07080a" top="#2a2d36">
          <div style={{position: 'absolute', inset: 22 * u, borderRadius: 20 * u, background: '#050608', overflow: 'hidden'}}>
            <div
              style={{
                position: 'absolute',
                left: 0,
                right: 0,
                bottom: 0,
                height: `${fill * 100}%`,
                background: 'linear-gradient(180deg,#ffe38a,#e09a12)',
                boxShadow: `0 -10px ${30 * u}px rgba(255,190,40,0.6)`,
              }}
            />
          </div>
        </Cuboid>
      </div>
      <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 30 * u, transform: `scale(${0.6 + 0.4 * bulb})`}}>
        <Glass style={{width: 300 * u, height: 300 * u, borderRadius: 50 * u, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: `0 0 ${80 * u * bulb}px rgba(255,210,90,${0.5 * bulb})`}}>
          <Icon name="home" size={150 * u} color={BRAND.gold} sw={1.6} />
        </Glass>
        <Icon name="bulb" size={120 * u} color={bulb > 0.5 ? BRAND.gold : '#3a3a40'} sw={1.6} />
      </div>
    </div>
  );
};

/* ================================================================== *
 *  H) الكهرباء أساس: نواة تدور حولها التفاصيل
 * ================================================================== */
const ORBIT: ('fridge' | 'phone' | 'bulb' | 'drop')[] = ['fridge', 'phone', 'bulb', 'drop'];

export const SceneH: React.FC = () => {
  const frame = useCurrentFrame();
  const t = useT();
  const {u} = useScale();
  const on = clamp01(sp(frame, T.hMere));
  const spin = (t - T.hMere) * 40;
  const R = 330 * u;
  return (
    <div style={{...ctr}}>
      <div style={{position: 'absolute', width: 380 * u, height: 380 * u, borderRadius: '50%', transform: `scale(${0.5 + 0.5 * on})`, background: `radial-gradient(circle at 35% 30%, #fff6d0, ${BRAND.gold} 45%, #9a6200 85%)`, boxShadow: `0 0 ${100 * u}px rgba(255,190,40,0.45)`, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
        <div style={{...txt(68 * u, '#0b0b0d')}}>الكهرباء</div>
      </div>
      {ORBIT.map((ic, i) => {
        const a = spin + (i * 360) / ORBIT.length;
        return (
          <div key={i} style={{position: 'absolute', transform: `rotate(${a}deg) translateX(${R}px) rotate(${-a}deg) scale(${on})`}}>
            <Glass style={{width: 170 * u, height: 170 * u, borderRadius: 40 * u, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
              <Icon name={ic} size={92 * u} color="#fff" sw={1.6} />
            </Glass>
          </div>
        );
      })}
    </div>
  );
};

/* ================================================================== *
 *  I) تخيّل أسبوعاً بلا كهرباء
 * ================================================================== */
export const SceneI: React.FC = () => {
  const frame = useCurrentFrame();
  const t = useT();
  const {u} = useScale();
  const q = clamp01(sp(frame, T.iImagine, {damping: 10, stiffness: 180}));
  const w = clamp01(sp(frame, T.iWeek, {damping: 8, stiffness: 220}));
  const flicker = t > T.iWeek ? 0.5 + 0.5 * Math.sin((t - T.iWeek) * 40) * clamp01(1 - (t - T.iWeek)) : 1;
  return (
    <div style={{...ctr, flexDirection: 'column', gap: 40 * u}}>
      <div style={{position: 'relative', width: 900 * u, height: 420 * u, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
        <div style={{position: 'absolute', transform: `scale(${q * (1 - w)})`, opacity: undefined}}>
          <Extrude text="؟" size={380 * u} color={BRAND.gold} edge="#7a4d00" glow={BRAND.gold} depth={18} />
        </div>
        <div style={{position: 'absolute', transform: `scale(${0.3 + 0.7 * w})`}}>
          <Extrude text="أسبوع" size={230 * u} color={BRAND.red} edge="#6a0712" glow={BRAND.red} depth={18} />
        </div>
      </div>
      <div style={{transform: `scale(${flicker})`}}>
        <Icon name="bulb" size={150 * u} color={w > 0.5 ? '#3a3a40' : BRAND.gold} sw={1.6} />
      </div>
    </div>
  );
};

/* ================================================================== *
 *  J) الختام: الشعار + الطاقة تبدأ بالمعرفة
 * ================================================================== */
export const SceneJ: React.FC = () => {
  const frame = useCurrentFrame();
  const t = useT();
  const {u} = useScale();
  const k = clamp01(sp(frame, T.jBrand, {damping: 13, stiffness: 120}));
  const line1 = clamp01(sp(frame, T.jStart));
  const line2 = clamp01(sp(frame, T.jKnow, {damping: 9, stiffness: 200}));
  const pulse = 1 + 0.03 * Math.sin((t - T.jKnow) * 6) * clamp01((t - T.jKnow) * 3);
  return (
    <div style={{...ctr, flexDirection: 'column', gap: 50 * u}}>
      <div style={{transform: `scale(${0.6 + 0.4 * k}) rotateY(${(1 - k) * 90}deg)`}}>
        <LogoCard size={560 * u} glow={line2} />
      </div>
      <div style={{display: 'flex', alignItems: 'center', gap: 26 * u, flexDirection: 'row-reverse'}}>
        <div style={{...txt(78 * u, '#fff'), opacity: line1}}>الطاقة تبدأ</div>
        <div style={{...txt(78 * u, BRAND.gold), opacity: line2, transform: `scale(${pulse})`, textShadow: `0 0 ${40 * u}px rgba(255,210,90,0.6)`}}>بالمعرفة</div>
      </div>
    </div>
  );
};

export const SCENE_MAP: Record<string, React.FC> = {
  A: SceneA, B: SceneB, C: SceneC, D: SceneD, E: SceneE,
  F: SceneF, G: SceneG, H: SceneH, I: SceneI, J: SceneJ,
};
