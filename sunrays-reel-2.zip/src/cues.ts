/**
 * cues.ts — يربط المشاهد والحركات بالكلمات المنطوقة فعليًا.
 * timing.json يُولَّد في GitHub Actions بواسطة scripts/align.py من ملف الصوت نفسه.
 * لا تكتب أرقام ثواني بيدك في المشاهد؛ استخدم startOf('كلمة') / endOf('كلمة').
 */
import timing from './timing.json';

// حماية: لا يُسمح بالتصيير بتوقيت تقديري (للمعاينة فقط). التوقيت الحقيقي يولّده align.py في GitHub Actions.
if ((timing as {_estimated_for_QA_only?: boolean})._estimated_for_QA_only) {
  const allow = typeof process !== 'undefined' && process.env && process.env.REMOTION_ALLOW_ESTIMATED === '1';
  if (!allow) {
    throw new Error('src/timing.json تقديري! شغّل: python scripts/align.py --audio public/voice.mp3 --script script.txt --out src/timing.json  (أو REMOTION_ALLOW_ESTIMATED=1 للمعاينة فقط)');
  }
}

export type W = {i: number; text: string; t0: number; t1: number; matched: boolean};
export const WORDS = (timing as {words: W[]}).words;
export const AUDIO_SECONDS: number =
  (timing as {duration?: number | null}).duration ?? WORDS[WORDS.length - 1].t1 + 0.3;

const nz = (w: string) =>
  w
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .split('')
    .filter((c) => /[\p{L}\p{N}]/u.test(c))
    .join('');

/** فهرس أول ظهور للكلمة بعد الفهرس from. يرمي خطأ واضحًا إذا لم توجد (فيفشل التصيير بدل أن يخرج فيديو خاطئ). */
export const find = (word: string, from = 0): number => {
  const k = nz(word);
  for (let i = from; i < WORDS.length; i++) if (nz(WORDS[i].text) === k) return i;
  throw new Error(`cue word not found: "${word}" (after index ${from})`);
};

/** وقت بدء النطق (ثانية) */
export const startOf = (word: string, from = 0) => WORDS[find(word, from)].t0;
/** وقت انتهاء النطق (ثانية) */
export const endOf = (word: string, from = 0) => WORDS[find(word, from)].t1;

/** مجموعة كلمات متتالية من فهرس إلى فهرس — للترجمة المتزامنة */
export const range = (i0: number, i1: number) => WORDS.slice(i0, i1 + 1);

/** عدد الفريمات الكلي = مدة الصوت + 0.8 ثانية لقطة ختامية */
export const TOTAL_FRAMES = Math.ceil((AUDIO_SECONDS + 0.8) * 30);

/** مؤشر تسلسلي: يبحث عن الكلمات بالترتيب كما تُنطق — يرمي خطأ واضحًا إذا لم توجد */
export const makeCursor = () => {
  let cur = 0;
  return (word: string) => {
    const i = find(word, cur);
    cur = i + 1;
    return i;
  };
};
