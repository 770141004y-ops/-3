import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Cairo';
import envelope from './envelope.json';
import {BRAND, FPS} from './brand';

export const {fontFamily} = loadFont('normal', {
  weights: ['600', '700', '900'],
  subsets: ['arabic', 'latin'],
});

export const seeded = (seed: number) => {
  const x = Math.sin(seed * 12.9898) * 43758.5453;
  return x - Math.floor(x);
};

export const useScale = () => {
  const {width, height} = useVideoConfig();
  const isV = height > width;
  // u: وحدة قياس العناصر الرئيسية (تصميمها على عرض 1080 في العمودي)
  const u = isV ? width / 1080 : (height / 1080) * 0.82;
  return {isV, u, width, height};
};

export const useT = () => useCurrentFrame() / FPS;

export const useEnv = () => {
  const frame = useCurrentFrame();
  return (envelope as number[])[frame] ?? 0;
};

/** spring يبدأ عند ثانية معيّنة (زمن مطلق) */
export const sp = (
  frame: number,
  atSec: number,
  cfg: {damping?: number; stiffness?: number; mass?: number} = {},
) =>
  spring({
    frame: frame - Math.round(atSec * FPS),
    fps: FPS,
    config: {damping: 13, stiffness: 140, mass: 0.8, ...cfg},
  });

export const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

/** نافذة ظهور ناعمة: 0 خارج [a,b] و1 داخلها مع تلاشي fade ثانية */
export const win = (t: number, a: number, b: number, fade = 0.2) =>
  clamp01(Math.min((t - a) / fade, (b - t) / fade));

export const lerp = (t: number, a: number, b: number, x0: number, x1: number) =>
  interpolate(t, [a, b], [x0, x1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

/* ----------------------------- أيقونات ----------------------------- */

export type IconName =
  | 'invoice' | 'box' | 'chart' | 'grid' | 'calc' | 'ai' | 'calendar'
  | 'headset' | 'shield' | 'folder' | 'building' | 'check' | 'star' | 'user'
  | 'drop' | 'signal' | 'truck' | 'fridge' | 'bulb' | 'phone' | 'sun' | 'battery' | 'home' | 'switch' | 'thermo' | 'warn';

export const Icon: React.FC<{name: IconName; size: number; color?: string; sw?: number}> = ({
  name,
  size,
  color = '#fff',
  sw = 1.8,
}) => {
  let body: React.ReactNode = null;
  switch (name) {
    case 'invoice':
      body = (<><path d="M6 3h9l4 4v14H6z" /><path d="M14 3v5h5" /><path d="M9 12h7M9 15h7M9 18h4" /></>);
      break;
    case 'box':
      body = (<><path d="M3 7l9-4 9 4v10l-9 4-9-4z" /><path d="M3 7l9 4 9-4M12 11v10" /></>);
      break;
    case 'chart':
      body = (<><path d="M4 3v17h17" /><path d="M8 16v-4M12 16V8M16 16v-6M20 16V6" strokeWidth={sw * 1.6} /></>);
      break;
    case 'grid':
      body = (<><rect x="3" y="4" width="18" height="16" rx="2" /><path d="M3 9h18M3 14h18M9 4v16M15 4v16" /></>);
      break;
    case 'calc':
      body = (<><rect x="5" y="3" width="14" height="18" rx="2" /><rect x="8" y="6" width="8" height="3" /><path d="M8 13h.01M12 13h.01M16 13h.01M8 17h.01M12 17h.01M16 17h.01" strokeWidth={sw * 1.5} /></>);
      break;
    case 'ai':
      body = (<><path d="M11 3l1.9 5.4L18 10l-5.1 1.6L11 17l-1.9-5.4L4 10l5.1-1.6z" /><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z" /></>);
      break;
    case 'calendar':
      body = (<><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M3 10h18M8 3v4M16 3v4M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01" strokeWidth={sw * 1.4} /></>);
      break;
    case 'headset':
      body = (<><path d="M4 14v-2a8 8 0 0116 0v2" /><rect x="3" y="14" width="4" height="6" rx="1.5" /><rect x="17" y="14" width="4" height="6" rx="1.5" /><path d="M19 20c0 1.5-2 2-4 2" /></>);
      break;
    case 'shield':
      body = (<><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z" /><path d="M8.5 12l2.5 2.5 4.5-5" /></>);
      break;
    case 'folder':
      body = <path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2z" />;
      break;
    case 'building':
      body = (<><rect x="5" y="3" width="14" height="18" rx="1" /><path d="M9 7h2M13 7h2M9 11h2M13 11h2M9 15h2M13 15h2M10 21v-3h4v3" /></>);
      break;
    case 'check':
      body = <path d="M5 12.5l4.5 4.5L19 7.5" strokeWidth={sw * 1.5} />;
      break;
    case 'star':
      body = <path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z" />;
      break;
    case 'user':
      body = (<><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7" /></>);
      break;
    case 'drop':
      body = <path d="M12 3c3.5 4.6 6 8 6 11a6 6 0 0 1-12 0c0-3 2.5-6.4 6-11z" />;
      break;
    case 'signal':
      body = (<><path d="M4 12a8 8 0 0 1 16 0" /><path d="M7 14a5 5 0 0 1 10 0" /><circle cx="12" cy="17" r="1.6" /></>);
      break;
    case 'truck':
      body = (<><path d="M2 6h12v10H2z" /><path d="M14 10h4l3 3v3h-7" /><circle cx="6" cy="18" r="2" /><circle cx="17" cy="18" r="2" /></>);
      break;
    case 'fridge':
      body = (<><rect x="5" y="3" width="14" height="18" rx="2" /><path d="M5 10h14M9 6v2M9 13v3" /></>);
      break;
    case 'bulb':
      body = (<><path d="M9 18h6M10 21h4" /><path d="M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z" /></>);
      break;
    case 'phone':
      body = (<><rect x="7" y="2.5" width="10" height="19" rx="2.5" /><path d="M11 18h2" /></>);
      break;
    case 'sun':
      body = (<><circle cx="12" cy="12" r="4" /><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1" /></>);
      break;
    case 'battery':
      body = (<><rect x="2" y="7" width="17" height="10" rx="2" /><path d="M22 10v4" /><path d="M6 10v4M10 10v4" /></>);
      break;
    case 'home':
      body = <path d="M3 11l9-8 9 8M5 10v10h14V10M10 20v-6h4v6" />;
      break;
    case 'switch':
      body = (<><rect x="7" y="2" width="10" height="20" rx="3" /><circle cx="12" cy="8" r="2" /></>);
      break;
    case 'thermo':
      body = (<><path d="M10 14V5a2 2 0 0 1 4 0v9a4 4 0 1 1-4 0z" /><path d="M12 9v6" /></>);
      break;
    case 'warn':
      body = (<><path d="M12 3l10 18H2z" /><path d="M12 10v5M12 18v.5" /></>);
      break;
  }
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color}
      strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
      {body}
    </svg>
  );
};

export const toneColor = (tone: 'red' | 'teal' | 'gold') =>
  tone === 'red' ? BRAND.red : tone === 'gold' ? BRAND.gold : BRAND.teal;

/** بطاقة زجاجية */
export const Glass: React.FC<{style?: React.CSSProperties; children?: React.ReactNode}> = ({
  style,
  children,
}) => (
  <div
    style={{
      boxSizing: 'border-box',
      background: 'linear-gradient(145deg, rgba(255,255,255,0.14), rgba(255,255,255,0.05))',
      border: '2px solid rgba(255,255,255,0.2)',
      backdropFilter: 'blur(14px)',
      boxShadow: '0 30px 80px rgba(0,0,0,0.4)',
      ...style,
    }}
  >
    {children}
  </div>
);
