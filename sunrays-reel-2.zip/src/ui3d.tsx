import React from 'react';
import {Img, staticFile} from 'remotion';
import {BRAND} from './brand';
import {clamp01, fontFamily, useT, useScale} from './ui';

/** opacity يُطبَّق فقط عند الحاجة: أي opacity < 1 على عنصر أب يُسطّح الأبعاد الثلاثية لأبنائه */
export const o = (v: number): number | undefined => (v >= 0.995 ? undefined : Math.max(0, v));

export const ctr: React.CSSProperties = {
  position: 'absolute',
  inset: 0,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
};

/** مسرح ثلاثي الأبعاد: منظور + حركة كاميرا هادئة */
export const Stage: React.FC<{rx?: number; ry?: number; children: React.ReactNode}> = ({
  rx = 0,
  ry = 0,
  children,
}) => {
  const t = useT();
  const {u} = useScale();
  return (
    <div style={{...ctr, perspective: 1500 * u, perspectiveOrigin: '50% 42%'}}>
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          transformStyle: 'preserve-3d',
          transform: `rotateX(${rx + Math.sin(t * 0.55) * 2.5}deg) rotateY(${ry + Math.sin(t * 0.4) * 7}deg)`,
        }}
      >
        {children}
      </div>
    </div>
  );
};

/** لوح بسُمك حقيقي (طبقات خلفية) */
export const Slab: React.FC<{
  w: number;
  h: number;
  r: number;
  depth?: number;
  face: string;
  side?: string;
  glow?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({w, h, r, depth = 16, face, side = '#082a6b', glow, style, children}) => {
  const layers: React.ReactNode[] = [];
  for (let i = 2; i <= depth; i += 2) {
    layers.push(
      <div
        key={i}
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: w,
          height: h,
          borderRadius: r,
          background: side,
          transform: `translateZ(${-i}px)`,
        }}
      />,
    );
  }
  return (
    <div style={{position: 'relative', width: w, height: h, transformStyle: 'preserve-3d', ...style}}>
      {layers}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          borderRadius: r,
          background: face,
          overflow: 'hidden',
          boxShadow: glow ? `0 0 ${w * 0.18}px ${glow}, 0 ${h * 0.06}px ${h * 0.12}px rgba(0,0,0,0.45)` : `0 ${h * 0.06}px ${h * 0.12}px rgba(0,0,0,0.45)`,
        }}
      >
        {children}
      </div>
    </div>
  );
};

/** متوازي مستطيلات بستة أوجه */
export const Cuboid: React.FC<{
  w: number;
  h: number;
  d: number;
  front: string;
  side: string;
  top: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({w, h, d, front, side, top, style, children}) => {
  const abs: React.CSSProperties = {position: 'absolute'};
  return (
    <div style={{position: 'relative', width: w, height: h, transformStyle: 'preserve-3d', ...style}}>
      <div style={{...abs, inset: 0, background: front, transform: `translateZ(${d / 2}px)`}}>{children}</div>
      <div style={{...abs, inset: 0, background: side, transform: `rotateY(180deg) translateZ(${d / 2}px)`}} />
      <div style={{...abs, top: 0, left: (w - d) / 2, width: d, height: h, background: side, transform: `rotateY(90deg) translateZ(${w / 2}px)`}} />
      <div style={{...abs, top: 0, left: (w - d) / 2, width: d, height: h, background: side, transform: `rotateY(-90deg) translateZ(${w / 2}px)`}} />
      <div style={{...abs, left: 0, top: (h - d) / 2, width: w, height: d, background: top, transform: `rotateX(90deg) translateZ(${h / 2}px)`}} />
      <div style={{...abs, left: 0, top: (h - d) / 2, width: w, height: d, background: side, transform: `rotateX(-90deg) translateZ(${h / 2}px)`}} />
    </div>
  );
};

/** نص بسُمك (extrude) بطبقات ظل */
export const Extrude: React.FC<{
  text: string;
  size: number;
  color?: string;
  depth?: number;
  edge?: string;
  glow?: string;
  style?: React.CSSProperties;
}> = ({text, size, color = '#fff', depth = 14, edge = '#0a4fb0', glow = BRAND.teal, style}) => {
  const shadows: string[] = [];
  for (let i = 1; i <= depth; i++) {
    const k = i / depth;
    const c = `rgb(${Math.round(10 + (1 - k) * 20)},${Math.round(60 + (1 - k) * 40)},${Math.round(150 - k * 70)})`;
    shadows.push(`${i * 0.9}px ${i * 1.3}px 0 ${i === 1 ? edge : c}`);
  }
  shadows.push(`0 ${depth * 2}px ${depth * 3}px rgba(0,0,0,0.5)`, `0 0 ${size * 0.35}px ${glow}`);
  return (
    <div
      style={{
        fontFamily,
        fontWeight: 900,
        fontSize: size,
        lineHeight: 1.15,
        color,
        textShadow: shadows.join(','),
        direction: 'rtl',
        whiteSpace: 'nowrap',
        ...style,
      }}
    >
      {text}
    </div>
  );
};

/** عمود عملات */
export const CoinStack: React.FC<{count: number; size: number; color?: string}> = ({count, size, color = BRAND.gold}) => {
  const coins: React.ReactNode[] = [];
  const hgt = size * 0.28;
  for (let i = 0; i < count; i++) {
    coins.push(
      <div
        key={i}
        style={{
          position: 'absolute',
          bottom: i * hgt * 0.62,
          left: 0,
          width: size,
          height: hgt,
          borderRadius: '50%',
          background: `linear-gradient(180deg, #ffe39a, ${color} 55%, #c98a10)`,
          border: `${Math.max(1, size * 0.02)}px solid rgba(120,70,0,0.55)`,
          boxSizing: 'border-box',
          boxShadow: '0 4px 8px rgba(0,0,0,0.35)',
        }}
      />,
    );
  }
  return <div style={{position: 'relative', width: size, height: size * 0.28 + count * hgt * 0.62}}>{coins}</div>;
};

/** شعار المنصة داخل بطاقة بيضاء ثلاثية الأبعاد */
export const LogoCard: React.FC<{size: number; glow?: number}> = ({size, glow = 0}) => {
  const {u} = useScale();
  const h = size * (1402 / 1546);
  const pad = 70 * u;
  return (
    <Slab
      w={size + pad}
      h={h + pad}
      r={64 * u}
      depth={22 * u}
      face="#fff"
      side="#bcd3ee"
      glow={`rgba(31,209,192,${0.35 + glow * 0.45})`}
    >
      <div style={{...ctr}}>
        <Img src={staticFile('logo.png')} style={{width: size, height: h}} />
      </div>
    </Slab>
  );
};

/** ختم/شارة دائرية */
export const Badge: React.FC<{size: number; color: string; children: React.ReactNode; k?: number}> = ({
  size,
  color,
  children,
  k = 1,
}) => (
  <div
    style={{
      width: size,
      height: size,
      borderRadius: '50%',
      background: `radial-gradient(circle at 30% 25%, #ffffff55, ${color} 55%)`,
      border: `${size * 0.06}px solid rgba(4,16,51,0.9)`,
      boxSizing: 'border-box',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transform: `scale(${clamp01(k)})`,
      boxShadow: `0 0 ${size * 0.5}px ${color}`,
    }}
  >
    {children}
  </div>
);
