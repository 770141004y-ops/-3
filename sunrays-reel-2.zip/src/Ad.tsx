import React from 'react';
import {AbsoluteFill, Audio, Img, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {BRAND, FPS} from './brand';
import {TOTAL_FRAMES, WORDS, W} from './cues';
import {FLASHES, SCENES, T} from './timeline';
import {SCENE_MAP} from './scenes';
import {clamp01, fontFamily, lerp, seeded, sp, toneColor, useEnv, useScale} from './ui';

/* ------------------------------------------------------------------ *
 *  الخلفية السينمائية
 * ------------------------------------------------------------------ */
const Particles: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const t = frame / FPS;
  return (
    <AbsoluteFill>
      {new Array(30).fill(0).map((_, i) => {
        const size = 4 + seeded(i + 1) * 11;
        const x = seeded(i + 50) * width;
        const speed = 25 + seeded(i + 90) * 80;
        const y = (((seeded(i + 130) * height - t * speed) % height) + height) % height;
        const drift = Math.sin(t * (0.5 + seeded(i + 7)) + i) * 25;
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x + drift,
              top: y,
              width: size,
              height: size,
              borderRadius: '50%',
              background: i % 3 === 0 ? BRAND.teal : '#fff3d6',
              opacity: 0.15 + seeded(i + 33) * 0.35,
              filter: 'blur(1px)',
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

const Background: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const env = useEnv();
  const t = frame / FPS;
  const big = Math.max(width, height);
  // توهّج أحمر في بداية الإعلان (الرفض) يتلاشى مع دخول الحل
  const red = 0.22 * (1 - clamp01((t - T.bDay1) / 1.2));
  return (
    <AbsoluteFill
      style={{
        background: `linear-gradient(${155 + Math.sin(t * 0.5) * 22}deg, #070707 0%, #17120a 52%, #2e2105 100%)`,
      }}
    >
      <div
        style={{
          position: 'absolute',
          width: big * 0.9,
          height: big * 0.9,
          left: width * 0.5 - big * 0.45 + Math.sin(t * 0.7) * 120,
          top: height * 0.28 - big * 0.45 + Math.cos(t * 0.6) * 120,
          borderRadius: '50%',
          background: `radial-gradient(circle, rgba(255,190,40,${0.16 + env * 0.2}) 0%, rgba(255,190,40,0) 65%)`,
        }}
      />
      <div
        style={{
          position: 'absolute',
          width: big * 0.9,
          height: big * 0.9,
          left: width * 0.5 - big * 0.45,
          top: height * 0.25 - big * 0.45,
          borderRadius: '50%',
          background: `radial-gradient(circle, rgba(255,59,77,${red}) 0%, rgba(255,59,77,0) 65%)`,
        }}
      />
      <div
        style={{
          position: 'absolute',
          width: big * 0.8,
          height: big * 0.8,
          left: width * 0.5 - big * 0.4 + Math.cos(t * 0.5) * 160,
          top: height * 0.85 - big * 0.4 + Math.sin(t * 0.8) * 100,
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(255,120,30,0.2) 0%, rgba(255,120,30,0) 65%)',
        }}
      />
      <AbsoluteFill
        style={{
          opacity: 0.06,
          backgroundImage:
            'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)',
          backgroundSize: '90px 90px',
          backgroundPosition: `${(t * 20) % 90}px ${(t * 20) % 90}px`,
        }}
      />
      <Particles />
      <AbsoluteFill
        style={{
          background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 45%, rgba(0,0,0,0.5) 100%)',
        }}
      />
    </AbsoluteFill>
  );
};

/* ------------------------------------------------------------------ *
 *  ومضات الاصطدام عند اللحظات الكبيرة
 * ------------------------------------------------------------------ */
const Flashes: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  let o = 0;
  let c = '#fff';
  for (const f of FLASHES) {
    const k = (t - f.t) / 0.28;
    if (k >= 0 && k < 1) {
      const v = f.a * (1 - k);
      if (v > o) {
        o = v;
        c = f.color;
      }
    }
  }
  if (o <= 0) return null;
  return <AbsoluteFill style={{background: c, opacity: o, mixBlendMode: 'screen'}} />;
};

/* ------------------------------------------------------------------ *
 *  نافذة المشهد — تظهر وتختفي في وقتها بالضبط
 * ------------------------------------------------------------------ */
const HeroWindow: React.FC<{
  a: number;
  b: number;
  fadeIn?: number;
  fadeOut?: number;
  children: React.ReactNode;
}> = ({a, b, fadeIn = 0.22, fadeOut = 0.18, children}) => {
  const t = useCurrentFrame() / FPS;
  const {isV, height} = useScale();
  if (t < a - 0.001 || t > b) return null;
  const inK = fadeIn > 0 ? clamp01((t - a) / fadeIn) : 1;
  const outK = fadeOut > 0 ? clamp01((b - t) / fadeOut) : 1;
  const scale = (0.95 + 0.05 * inK) * lerp(t, a, b, 1, 1.045);
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        top: isV ? height * 0.085 : height * 0.11,
        height: isV ? height * 0.54 : height * 0.57,
        opacity: inK * outK,
        transform: `scale(${scale})`,
      }}
    >
      {children}
    </div>
  );
};

/* ------------------------------------------------------------------ *
 *  الترجمة المتزامنة مع الصوت كلمة بكلمة
 * ------------------------------------------------------------------ */
const normalize = (w: string) =>
  w
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .split('')
    .filter((c) => /[\p{L}\p{N}]/u.test(c))
    .join('');

// ألوان الكلمات المفصلية (تُقارَن بعد التطبيع)
const TONES: Record<'gold' | 'teal' | 'red', string[]> = {
  gold: ['سبعة', 'أسبوع', 'الشمسية', 'الطاقة', 'بالمعرفة'],
  teal: ['الحقيقة', 'المناسب', 'تخزين', 'البطاريات'],
  red: ['ستنقطع', 'للتلف', 'توقفت', 'تحديات'],
};
const toneOf = (w: string): 'gold' | 'teal' | 'red' | null => {
  const n = normalize(w);
  for (const k of ['gold', 'teal', 'red'] as const) if (TONES[k].some((x) => normalize(x) === n)) return k;
  return null;
};

// كلمات لاتينية متتالية (SUN RAYS) تُدمج في عنصر واحد حتى لا ينعكس ترتيبها في اتجاه RTL
const isLatin = (w: string) => /^[A-Za-z ]+$/.test(w) && /[A-Za-z]/.test(w);
const mergeLatin = (words: W[]): W[] => {
  const out: W[] = [];
  for (const w of words) {
    const prev = out[out.length - 1];
    if (prev && isLatin(prev.text) && isLatin(w.text)) {
      out[out.length - 1] = {...prev, text: `${prev.text} ${w.text}`, t1: w.t1};
    } else out.push({...w});
  }
  return out;
};

type Group = {words: W[]; show0: number; show1: number; chars: number};
const BREAK = /[،,.؟?!:؛]$/;
const buildGroups = (): Group[] => {
  const groups: Group[] = [];
  let cur: W[] = [];
  const flush = () => {
    if (!cur.length) return;
    groups.push({words: cur, show0: cur[0].t0 - 0.06, show1: cur[cur.length - 1].t1 + 0.3, chars: cur.map((w) => w.text).join(' ').length});
    cur = [];
  };
  WORDS.forEach((w, i) => {
    cur.push(w);
    const next = WORDS[i + 1];
    if (BREAK.test(w.text) || cur.length >= 4 || (next && next.t0 - w.t1 > 0.45)) flush();
  });
  flush();
  groups.forEach((g, i) => {
    const nx = groups[i + 1];
    if (nx) g.show1 = Math.min(g.show1, nx.show0 - 0.02);
  });
  return groups;
};
const GROUPS = buildGroups();

const CaptionGroup: React.FC<{g: Group}> = ({g}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const {isV, width, height} = useScale();
  const base = isV ? 112 : 92;
  const size = base * (g.chars > 34 ? 0.78 : g.chars > 22 ? 0.9 : 1);
  const exit = clamp01((g.show1 - t) / 0.12);
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        top: isV ? height * 0.655 : height * 0.69,
        height: isV ? height * 0.2 : height * 0.22,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        opacity: exit,
      }}
    >
      <div
        style={{
          direction: 'rtl',
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          columnGap: size * 0.26,
          rowGap: size * 0.02,
          maxWidth: isV ? width * 0.9 : width * 0.88,
          textAlign: 'center',
        }}
      >
        {mergeLatin(g.words).map((w, i) => {
          const s = sp(frame, w.t0, {damping: 12, stiffness: 190, mass: 0.6});
          const active = t >= w.t0 && t < w.t1 + 0.05;
          const tone = toneOf(w.text);
          const col = tone ? toneColor(tone) : BRAND.teal;
          return (
            <span
              key={i}
              style={{
                fontFamily,
                fontWeight: 900,
                fontSize: size,
                lineHeight: 1.3,
                display: 'inline-block',
                direction: /[A-Za-z]/.test(w.text) ? 'ltr' : 'rtl',
                color: tone ? col : '#fff',
                opacity: clamp01(s * 1.6),
                transform: `translateY(${(1 - clamp01(s)) * 50}px) scale(${(0.8 + 0.2 * clamp01(s)) * (active ? 1.07 : 1)})`,
                textShadow: active ? `0 0 ${size * 0.35}px ${col}, 0 6px 26px rgba(0,0,0,0.6)` : '0 6px 26px rgba(0,0,0,0.65)',
              }}
            >
              {w.text.replace(/["«»“”]/g, '')}
            </span>
          );
        })}
      </div>
    </div>
  );
};

const Captions: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  const g = GROUPS.find((x) => t >= x.show0 && t <= x.show1);
  if (!g) return null;
  return <CaptionGroup key={g.show0} g={g} />;
};

/* ------------------------------------------------------------------ *
 *  موجة الصوت / شريط التقدم / الشارة العلوية / حُبيبات الفيلم
 * ------------------------------------------------------------------ */
const Waveform: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height, isV} = useScale();
  const env = useEnv();
  const t = frame / FPS;
  const N = 43;
  const barW = Math.min(isV ? 11 : 9, (width * 0.8) / (N * 2));
  const maxH = height * 0.085;
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: height * (isV ? 0.045 : 0.035),
        height: maxH,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: barW * 0.8,
        direction: 'ltr',
        opacity: 0.9,
      }}
    >
      {new Array(N).fill(0).map((_, i) => {
        const c = (i - (N - 1) / 2) / ((N - 1) / 2);
        const bell = Math.exp(-c * c * 2.2);
        const wob = 0.55 + 0.45 * Math.abs(Math.sin(i * 1.7 + t * 9));
        const h = Math.max(6, (0.08 + env * (0.25 + 0.75 * bell) * wob) * maxH);
        return (
          <div
            key={i}
            style={{
              width: barW,
              height: h,
              borderRadius: 999,
              background: `linear-gradient(180deg, ${BRAND.gold}, #c27a08)`,
              opacity: 0.5 + 0.5 * bell,
              boxShadow: '0 0 12px rgba(255,210,90,0.45)',
            }}
          />
        );
      })}
    </div>
  );
};

const ProgressBar: React.FC = () => {
  const frame = useCurrentFrame();
  const {height} = useScale();
  const p = Math.min(1, frame / (TOTAL_FRAMES - 1));
  return (
    <div
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: Math.max(6, height * 0.005),
        background: 'rgba(255,255,255,0.1)',
        direction: 'ltr',
      }}
    >
      <div
        style={{
          width: `${p * 100}%`,
          height: '100%',
          background: `linear-gradient(90deg, ${BRAND.teal}, #ffd25a)`,
          boxShadow: `0 0 18px ${BRAND.teal}`,
        }}
      />
    </div>
  );
};

const TopBadge: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  const {u, isV, height} = useScale();
  const vis = clamp01((t - 0.3) / 0.3) * clamp01((T.jBrand - 0.1 - t) / 0.2);
  if (vis <= 0) return null;
  return (
    <div
      style={{
        position: 'absolute',
        top: isV ? height * 0.032 : height * 0.025,
        left: 0,
        right: 0,
        display: 'flex',
        justifyContent: 'center',
        opacity: vis,
      }}
    >
      <div
        style={{
          background: '#fff',
          borderRadius: 999,
          padding: `${8 * u}px ${24 * u}px`,
          display: 'flex',
          alignItems: 'center',
          gap: 14 * u,
          boxShadow: '0 10px 40px rgba(0,0,0,0.35)',
          direction: 'rtl',
        }}
      >
        <Img src={staticFile('logo.png')} style={{width: 64 * u, height: 64 * u * (1402 / 1546)}} />
        <span style={{fontFamily, fontWeight: 900, fontSize: 32 * u, color: BRAND.navy}}>
          أشعة الشمس للطاقة المتجددة
        </span>
      </div>
    </div>
  );
};

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width="100%" height="100%">
        <filter id="g">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed={frame % 9} />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#g)" />
      </svg>
    </AbsoluteFill>
  );
};

/* ------------------------------------------------------------------ *
 *  التركيب الكامل
 * ------------------------------------------------------------------ */
export const Ad: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: BRAND.navy}}>
      <Audio src={staticFile('music.mp3')} volume={0.6} />
      <Audio src={staticFile('voice.mp3')} />
      <Background />

      {SCENES.map((sc, i) => {
        const Scene = SCENE_MAP[sc.id];
        return (
          <HeroWindow key={sc.id} a={sc.a} b={sc.b} fadeIn={i === 0 ? 0 : 0.2} fadeOut={i === SCENES.length - 1 ? 0 : 0.16}>
            <Scene />
          </HeroWindow>
        );
      })}

      <Captions />
      <Waveform />
      <TopBadge />
      <ProgressBar />
      <Flashes />
      <Grain />
    </AbsoluteFill>
  );
};
