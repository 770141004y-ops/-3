/**
 * timeline.ts — كل لحظة مربوطة بكلمة منطوقة (وقتها من timing.json = من الصوت نفسه).
 * الترتيب هنا يجب أن يطابق ترتيب النطق.
 */
import {WORDS, TOTAL_FRAMES, makeCursor} from './cues';
import {BRAND, FPS} from './brand';

const nx = makeCursor();
const s = (w: string) => WORDS[nx(w)].t0; // بداية نطق الكلمة

export const T = {
  // A) السؤال الافتتاحي والأيام السبعة
  aWhat: s('ماذا'), aSeven: s('سبعة'), aLong: s('متواصلة'),
  // B) اليوم الأول: انطفاء المدن
  bDay1: s('الأول'), bOff: s('ستنقطع'), bHomes: s('المنازل'),
  // C) اليوم الثاني: الشبكات
  cDay2: s('الثاني'), cWater: s('المياه'), cSignal: s('والاتصالات'),
  // D) اليوم الثالث: الثلاجة
  dDay3: s('الثالث'), dFridge: s('المبردة'), dSpoil: s('للتلف'),
  // E) مرور الأيام وتفاصيل الحياة
  eTime: s('مرور'), eDetail: s('أبسط'),
  // F) السؤال عن الحل
  fQ: s('سؤال'), fSolar: s('الشمسية'), fStore: s('تخزين'),
  // G) الحل: البطاريات والاستمرار
  gTruth: s('الحقيقة'), gBattery: s('البطاريات'), gContinue: s('لاستمرار'), gFit: s('المناسب'),
  // H) الكهرباء أساس تفاصيل الحياة
  hMere: s('مجرد'), hBase: s('أساس'),
  // I) تخيّل حياتك بلا كهرباء
  iImagine: s('تخيلت'), iWeek: s('أسبوع'),
  // J) الختام
  jBrand: s('الطاقة'), jStart: s('تبدأ'), jKnow: s('بالمعرفة'),
};

export const END = TOTAL_FRAMES / FPS + 1;

/** نوافذ المشاهد: كل مشهد يبدأ عند كلمته وينتهي عند بداية المشهد التالي */
export const SCENES = [
  {id: 'A', a: 0, b: T.bDay1},
  {id: 'B', a: T.bDay1, b: T.cDay2},
  {id: 'C', a: T.cDay2, b: T.dDay3},
  {id: 'D', a: T.dDay3, b: T.eTime},
  {id: 'E', a: T.eTime, b: T.fQ},
  {id: 'F', a: T.fQ, b: T.gTruth},
  {id: 'G', a: T.gTruth, b: T.hMere},
  {id: 'H', a: T.hMere, b: T.iImagine},
  {id: 'I', a: T.iImagine, b: T.jBrand},
  {id: 'J', a: T.jBrand, b: END},
] as const;

/** ومضات عند الكلمات المفصلية */
export const FLASHES: {t: number; color: string; a: number}[] = [
  {t: T.bOff, color: BRAND.red, a: 0.35},
  {t: T.dSpoil, color: BRAND.red, a: 0.4},
  {t: T.gTruth, color: BRAND.gold, a: 0.3},
  {t: T.gFit, color: BRAND.green, a: 0.3},
  {t: T.iWeek, color: BRAND.red, a: 0.45},
  {t: T.jKnow, color: BRAND.gold, a: 0.5},
];
