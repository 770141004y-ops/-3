voice.mp3 و logo.png موجودان هنا. timing.json يُنشأ تلقائيًا في GitHub Actions.
